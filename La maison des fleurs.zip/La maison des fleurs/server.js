const express = require('express');
const app = express();
const port = 3000;

// Configurar EJS como motor de plantillas
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// Servir archivos estáticos desde la carpeta 'public'
app.use(express.static('public'));
app.use(express.urlencoded({ extended: false })); // Para procesar datos de formularios

// Rutas
app.get('/', (req, res) => {
    res.render('index');
});

app.get('/inicio', (req, res) => {
    res.render('inicio');
});

app.get('/dama', (req, res) => {
    res.render('dama');
});

app.get('/caballero', (req, res) => {
    res.render('caballero');
});

app.get('/carrocompra', (req, res) => {
    res.render('carrocompra');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.get('/registro', (req, res) => {
    res.render('registro');
});

app.post('/registro', (req, res) => {
    // Aquí iría la lógica para procesar los datos del formulario de registro
    console.log('Datos del formulario de registro:', req.body);
    res.render('registrodatos', { datos: req.body }); // Redirigir a la página de datos de registro
});

app.get('/registrodatos', (req, res) => {
    // Esta ruta podría no ser directamente accesible por GET si los datos vienen de un POST
    // Si necesitas acceder a ella directamente para pruebas, puedes pasar datos de ejemplo
    const datosEjemplo = {
        nombre_completo: 'Guadalupe Rodriguez',
        correo: 'Rodri@gmail.com',
        ciudad: 'Mexico',
        direccion: 'Av. Siempre viva #123',
        numero_telefonico: '6675889966'
    };
    res.render('registrodatos', { datos: datosEjemplo });
});

app.get('/formapago', (req, res) => {
    res.render('formapago'); // Utilizando el nombre del archivo proporcionado
});

app.get('/pedido-confirmado', (req, res) => {
    res.render('pedidoconfirmado');
});

// ... (tu ruta POST para /registro si la tienes) ...

app.listen(port, () => {
    console.log(`La maison des fleurs esta en linea ahora en http://localhost:${port}`);
});